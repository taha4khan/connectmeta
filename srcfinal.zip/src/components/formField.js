// Component
function Field() {
    return (
        <>
            <div className='b1'>
                <label>Username</label>
                <input type="text" placeholder='Username' />
            </div>
        </>
    );
}

export default Field;