import { useState, useEffect } from "react";
import axios from "axios";
import Web3 from "web3";
import contractData from "./erc20.json"


// Infura
import { create } from 'ipfs-http-client';

// Component


//submit
function submitt(){
  console.log("use to set function in submit button");
}
function check_verify(){
  console.log("this degree ivalid and awarded by deen of university");

}



//check verify 
function App ()  {
  
  const [count, setCount] = useState(0);
  const [Counter, setCounter] = useState(0);
  const [users, setUsers] = useState([]);
  const [auth, setauth] = useState([]);
  
  const [myWallet, setMyWallet] = useState("");
  const [myBalance, setMyBalance] = useState("");
  const [myWeb3, setMyWeb]= useState([])

  const [show, setShow] = useState(false);
  const [alotshow, setAlotshow] = useState(false);


  
  const connectWallet = async () => {
    if (window.ethereum) {
      const myWeb3 = await new Web3(window.ethereum)
      console.log(myWeb3);
      setMyWeb(myWeb3)
      await window.ethereum.enable()
      .then(async wallet => {
        console.log(wallet);
          setMyWallet(wallet[0])
          
          setMyBalance(await myWeb3.eth.getBalance(wallet[0]))
          console.log(await myWeb3.eth.getAccounts());
         // console.log(await myWeb3.eth.sendSignedTransaction)

          // console.log(await myWeb3.eth.getTransaction("0x5dba8380c441c2cb6d32ab8866fcc351dd756e0b01e9689e7c1c240f3dffa3ce"));
          // console.log(await myWeb3.eth.getTransactionReceipt("0x5dba8380c441c2cb6d32ab8866fcc351dd756e0b01e9689e7c1c240f3dffa3ce"));
        })

      } else {
        alert("Install Metamask")
      }
    }
    
    // function App() {
      //   const [myWeb3, setMyWeb]= useState([])
//   const [wallet, setWallet]= useState("Connect Wallet")

//   const connectWallet = async () => {
//     if (window.ethereum) {
//       const myWeb3 = await new Web3(window.ethereum)
//       console.log(myWeb3);
//       await window.ethereum.enable()
//       .then((a) => {
//         console.log(a);
//         setMyWeb(myWeb3)
//         setWallet(a[0])
//       })
//       .catch(e => {
//         console.log(e);
//       })
//     } else {
  //       alert("Install Metamask")
//     }
//   }

//   async function loadWeb3() {
//     const myContract =  await new myWeb3.eth.Contract(contractData.abi, contractData.address)
//     console.log(myContract);
//     console.log("wallet", wallet);

//     //console.log(await myContract.methods.totalSupply().call());
//    // console.log(await myContract.methods.balanceOf("0x8Fab43b8152B854ac501A4Cc5e539a64d9f88375").call(), "0x8Fab43b8152B854ac501A4Cc5e539a64d9f88375");
//    // console.log(await myContract.methods.balanceOf("0xce19f9c5352501cd560e55578f4c54a099cf6ded").call(), "0xce19f9c5352501cd560e55578f4c54a099cf6ded");
//     console.log(await myContract.methods.transfer("0x8Fab43b8152B854ac501A4Cc5e539a64d9f88375", "link")
//     .send({from: wallet}))
//     .then( res => {
//       console.log(res);
//     })
//     .catch(e => {
//       console.log(e);
//     })
//   }

  async function IPFS(e) {
    
    var projectId = "2Dydzylgtshpp6qkCIo9RTCI7kB"
    var projectSecret = "38173d9bb7e11b37257301b9d49b4c43"
    const auth = 'Basic ' + Buffer.from(projectId + ':' + projectSecret).toString('base64');
    alert("IPFS")
    
    const file = e.target.files[0]
    try {

      const ipfs = create({
        host: "ipfs.infura.io",
        port: 5001,
        protocol: "https",
        headers: {
          authorization: auth,
        }
      })

      await ipfs.add(file)
        .then(async (res) => {
          console.log("then");
          console.log(res);
          ///// res res
         // response = (res);
          const asd = `https://ipfs.infura.io/ipfs/${res.path}`;
         const abc = res.path;

          console.log(myWeb3);
          const myContract =  await new myWeb3.eth.Contract(contractData.abi, contractData.address)
          console.log(myContract);
          console.log("wallet", myWallet);
  
          //console.log(await myContract.methods._mint("0x753C1081CF2d77871D2bc3205a762c026441AdA3", asd).send({ from: myWallet}));
          // await myContract.methods._verification() 
      
    
        })
        .catch((res) => {
          console.log("catch");
          console.log(res);

        })

      // const added = await client.add("file")
      // const url = `https://ipfs.infura.io/ipfs/${added.path}`
      // console.log(url);
      // updateFileUrl(url)
    } catch (error) {
      return console.log('Error uploading file: ', error)
    }
  }

        // minting
        async function fm(){
          console.log(myWeb3);
          const myContract =  await new myWeb3.eth.Contract(contractData.abi, contractData.address)
          console.log(myContract);
          console.log("wallet", myWallet);
          console.log(await myContract.methods._mint("0x753C1081CF2d77871D2bc3205a762c026441AdA3","asd").send({ from: myWallet}))
        

          // .then(async()=>
          // {
          //   const myContract =  await new myWeb3.eth.Contract(contractData.abi, contractData.address)
          //   await myContract.methods._verification(res.path).send({myWallet})
          // })
        }

        //     <button onClick={TokenURI} style={{ padding: "20px"}}> check verify</button>
        // async function TokenURI() 
        // {
        //   const myContract =  await new myWeb3.eth.Contract(contractData.abi, contractData.address)
        //   console.log(myContract);
        //   console.log("wallet", myWallet);
          
        //   // const myContract =  await new myWeb3.eth.Contract(contractData.abi, contractData.address)
        //     await myContract.methods._tokenURI().send({from :myWallet[0]})
        // }

        




  return (
    <> 
    <div className="bb" >
      <div style={{ display: "flex" }}>
        <div>
          <div className="bv">
          <p> {myWallet == "" ? "Wallet Not Connected" : `${myWallet}`} </p> </div>
          <p> {myWallet == "" ? "" : `${myBalance} => ${(parseFloat(myBalance) / 1000000000000000000).toFixed(2)} CRYPTO`} </p>
        </div>
        <div>
          <button onClick={connectWallet}>Connect to Metamask</button>
        </div>
<div className ="bbb">
        <div>
         <input type="file" onChange={(e) => IPFS(e)} />  </div>
        </div>
        </div>
      </div>
      
      <div className="bg" style={{ padding: "50px" }}>

<label className="adress"></label>
        
        
              {/* <Login /> */}
      </div>
        
            <div className='b1'>
              <div style={{ width: "20vw", height: "8vh" }}>
                <label>DEGREE AWARDED</label>   
                <input type="text" placeholder='address' />
            </div>
</div>

<div className = "b1">
<div>
{alotshow && <p> allotted to student address  </p>}
            <button type = "button" onClick={() =>setAlotshow(!alotshow)}  style={{ padding: "20px"}}  > send on </button>     
  {/* <button  onClick={submitt}  type="submit" value="Submit"   >SUBMMIT</button> */}
      </div>   </div>



        <div className="bg">
        <div style={{ width: "100%", height: "100%", display: "flex", justifyContent: "center", flexDirection: "column" }}>
          <h1>ONLY   DEAN   CAN   ALLOT   DEGREE: { myWallet}</h1>
          <div>
            <button onClick={fm} style={{ padding: "20px"}}>mint </button>
        
          </div>
          
          <div>
          <div>
            
            {show && <p>verified  Degree</p>}
            <button type = "button" onClick={() =>setShow(!show)}  style={{ padding: "20px"}}  >verify </button>
          </div>
            {/* <button onClick={check_verify} style={{ padding: "20px"}}> check verify</button> */}

              <input type="text" placeholder='check' />
          </div>

        </div> 
        </div>

    </>

  );
  }

 export default App;



